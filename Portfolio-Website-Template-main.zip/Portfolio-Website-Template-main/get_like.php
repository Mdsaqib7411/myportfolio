<?php
include 'config.php';

session_start();
$user_ip = $_SERVER['REMOTE_ADDR'];
$totalLikes = $conn->query("SELECT COUNT(*) AS total FROM likes")->fetch_assoc()['total'];
$hasLiked = $conn->query("SELECT 1 FROM likes WHERE ip = '$user_ip'")->num_rows > 0;

echo json_encode(["totalLikes" => $totalLikes, "hasLiked" => $hasLiked]);
?>
