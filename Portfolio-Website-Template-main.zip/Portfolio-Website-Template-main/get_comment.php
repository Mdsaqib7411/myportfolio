<?php
header('Content-Type: application/json');
include 'config.php';

try {
    $result = $conn->query("SELECT email, comment, created_at FROM comments ORDER BY created_at DESC");

    $comments = [];
    while ($row = $result->fetch_assoc()) {
        $comments[] = [
            'email' => htmlspecialchars($row['email'], ENT_QUOTES, 'UTF-8'),
            'comment' => htmlspecialchars($row['comment'], ENT_QUOTES, 'UTF-8'),
            'created_at' => $row['created_at']
        ];
    }

    echo json_encode($comments);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
