<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Md Saqib Hussain Portfolio</title>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">
    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">



<style>

/*======================================
//--//-->   ABOUT
======================================*/

.about-mf .box-shadow-full {
  padding-top: 4rem;
  padding-bottom: 4rem;
}

.about-mf .about-img {
  margin-bottom: 2rem;
}

.about-mf .about-img img {
  margin-left: 10px;
}


.skill-mf .progress {
  /* background-color: #cde1f8; */
  margin: .5rem 0 1.2rem 0;
  border-radius: 0;
  height: .7rem;
}

.skill-mf .progress .progress-bar {
  height: .7rem;
  background-color: #ffbd39;
}


/* Animation styles */
#typing-animation {
  position: relative;
  font-size: 30px;
  font-weight: bold;
  color: rgb(255, 255, 255);
  overflow: hidden;
  white-space: nowrap;
  animation: typing 3s steps(20, end) infinite;
}

#typing-animation:before {
  content: "";
  /* position: absolute; */
  top: 0;
  left: 0;
  width: 0;
  height: 100%;
  background-color: #ccc;
  animation: typing-cursor 0.5s ease-in-out infinite;
}

@keyframes typing {
  from {
    width: 0;
  }
  to {
    width: 100%;
  }
}

@keyframes typing-cursor {
  from {
    width: 5px;
  }
  to {
    width: 0;
  }
}


/* project image zoom effect */

.zoom-effect {
  overflow: hidden;
  transition: transform 0.3s ease-out;
}

.zoom-effect:hover {
  transform: scale(1.1);
}


</style>


  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
	  
	  
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar ftco-navbar-light site-navbar-target" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.html">Md Saqib Hussain</a>
	      <button class="navbar-toggler js-fh5co-nav-toggle fh5co-nav-toggle" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav nav ml-auto">
	          <li class="nav-item"><a href="#home-section" class="nav-link"><span>Home</span></a></li>
	          <li class="nav-item"><a href="#about-section" class="nav-link"><span>About</span></a></li>
	          <li class="nav-item"><a href="#resume-section" class="nav-link"><span>Resume</span></a></li>
	          <li class="nav-item"><a href="#project-section" class="nav-link"><span>Projects</span></a></li>
	          <li class="nav-item"><a href="#contact-section" class="nav-link"><span>Contact</span></a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
	  <section id="home-section" class="hero">
		  <div class="home-slider  owl-carousel">
	       <div class="slider-item ">
	      	<div class="overlay"></div>
	         <div class="container">
	          <div class="row d-md-flex no-gutters slider-text align-items-end justify-content-end" data-scrollax-parent="true">
	          	<div class="one-third js-fullheight order-md-last img" style="background-image:url(images/bg_1.png);">
	          	 <div class="overlay"></div>
	          	</div>
		          <div class="one-forth d-flex  align-items-center ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
		          	<div class="text">
		          		<span class="subheading">Hello!</span>
			            <h1 class="mb-4 mt-3">I'm <span>Md Saqib Hussain</span></h1>

						<!-- Element to contain animated typing -->
						<span id="typing-animation"></span>

						<script>

						// Initialize the typing animation
						const typingAnimationElement = document.getElementById('typing-animation');

						// Create an array of typing text
						const typingTexts = [
						'Engineer  ',
						'Student  ',
						'Fuck You  ',
						];

						// Create a function to display the typing animation for a given text
						function playTypingAnimation(text) {
						// Loop through each character and add it to the element
						for (let i = 0; i < text.length; i++) {
							setTimeout(() => {
							typingAnimationElement.textContent += text[i];
							}, i * 200); // Increase the delay to slow down the typing animation
						}

						// Once the animation is complete, reset the text and start over
						setTimeout(() => {
							typingAnimationElement.textContent = '';
							playTypingAnimation(typingTexts[(typingTexts.indexOf(text) + 1) % typingTexts.length]);
						}, text.length * 200);
						}

						// Start the typing animation loop
						playTypingAnimation(typingTexts[0]);

						</script>

						<br>
						<br>
			            <h2>A full-Stack web developer</h2>
						<!-- <h2 class="d-flex" style="margin-bottom: 0">With over 5 years of experience</h2> -->
						<!-- <br> -->
		            </div>
		          </div>
	        	</div>
	        </div>
	      </div>
		</div>
    </section>



    <section class="ftco-about img ftco-section ftco-no-pb" id="about-section">
    	<div class="container">
			<div class="row">
				<div class="row d-flex align-items-stretch">
				<!-- <div class="row d-flex"> -->
					<div class="col-md-6 col-lg-5 d-flex">
						<div class="img-about img d-flex align-items-stretch">
							<div class="overlay">
								<div class="row">
									<div class="col-sm-6 col-md-5">
									  <div class="about-img">
										<img src="images/about-me.png" class="img-fluid rounded b-shadow-a" alt="">
									  </div>
									</div>
									<!-- Details next to profile image -->
									<div class="col-sm-6 col-md-7">
									  <div class="about-info">
										<p><span class="title-s">Name: </span> <span>Md Saqib Hussain</span></p>
										<p><span class="title-s">Job Role: </span> <span>full-Stack web developer</span></p>
										<p><span class="title-s">Experience: </span> <span>As a beginner</span></p>
										<p><span class="title-s">Address: </span> <span>Bhopal, India</span></p>
									  </div>
									</div>
								  </div>

								<div class="skill-mf">
									<p class="title-s">Skills</p>
									<span>MYSQL</span> <span class="pull-right">95%</span>
									<div class="progress">
										<div class="progress-bar" role="progressbar" style="width: 95%;" aria-valuenow="95" aria-valuemin="0"
											aria-valuemax="100"></div>
									</div>
									
									<span>HTML</span> <span class="pull-right">85%</span>
									<div class="progress">
										<div class="progress-bar" role="progressbar" style="width: 85%" aria-valuenow="85" aria-valuemin="0"
											aria-valuemax="100"></div>
									</div>
									
									<span>CSS</span> <span class="pull-right">90%</span>
									<div class="progress">
										<div class="progress-bar" role="progressbar" style="width: 90%" aria-valuenow="90" aria-valuemin="0"
											aria-valuemax="100"></div>
									</div>
									
									<span>JS</span> <span class="pull-right">85%</span>
									<div class="progress">
										<div class="progress-bar" role="progressbar" style="width: 85%" aria-valuenow="85" aria-valuemin="0"
											aria-valuemax="100"></div>
									</div>
									
									<span>API</span> <span class="pull-right">50%</span>
									<div class="progress">
										<div class="progress-bar" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0"
											aria-valuemax="100"></div>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					<div class="col-md-6 col-lg-7 pl-lg-5 pb-5">
						<div class="row justify-content-start pb-3">
							<div class="col-md-12 heading-section ftco-animate">
								
								<h1 class="big">About</h1>
								<h2 class="mb-4">About Me</h2>
								
								<p>Aspiring Full-Stack Developer with a strong passion for building web applications.
									Currently learning and working with HTML, CSS, JavaScript, React, Node.js, and MongoDB to develop interactive and responsive websites.</p>
								<ul class="about-info mt-4 px-md-0 px-2">
									<li class="d-flex"><span>Profile:</span> <span>Full-Stack developer</span></li>
									<li class="d-flex"><span>Domain:</span> <span>Html, Css, Js, API, React, Node JS, MySqi</span></li>
									<li class="d-flex"><span>Education:</span> <span>Bachelor of Engineering</span></li>
									<li class="d-flex"><span>Language:</span> <span>English, Hindi</span></li>
									<li class="d-flex"><span>Other Skills:</span> <span>C, C++, Python</span></li>
									<li class="d-flex"><span>Interest:</span> <span>Traveling, Data analytics</span></li>
									
								</ul>
							</div>
						</div>


						<div class="counter-wrap ftco-animate d-flex mt-md-3">
							<div class="text">
								<p class="mb-4">
									<span class="number" data-number="3">0</span> <span>+</span>
									<span> Projects</span>
								</p>
								<p><a href="https://www.linkedin.com/in/md-saqib-hussain-7411L7295/" class="btn btn-primary py-3 px-3">LinkedIn</a></p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
    </section>



	
    <section class="ftco-section ftco-no-pb" id="resume-section">
    	<div class="container">
    		<div class="row justify-content-center pb-5">
          <div class="col-md-10 heading-section text-center ftco-animate">
          	<h1 class="big big-2">Resume</h1>
            <h2 class="mb-4">Resume</h2>
            <p>Aspiring Full-Stack Developer with a strong foundation in web development and problem-solving. Passionate about building scalable, responsive applications using HTML, CSS, JavaScript, React, Node.js, Express, and MongoDB. Experienced in developing and optimizing user-friendly interfaces, backend APIs, and database management.
				 Strong analytical mindset with a keen interest in learning new technologies and contributing to impactful projects.</p>
          </div>
        </div>

		<div class="row">
			<h1 class="big-4">Experience</h1>
			<div class="underline"></div>
		</div>
		<br>
		
		<div class="row">
				<div class="col-md-6">
					<div class="resume-wrap ftco-animate">
						<span class="date">2025-Present</span>
						<h2>full-Stack web developer</h2>
						<span class="position">Online Voting System</span>
						<p class="mt-4">Developed a cutting-edge online voting platform for Dentsu International, serving 10,000+ professionals across global markets. 
							<ul>
								<li>Engineered a blockchain-based voting protocol ensuring tamper-proof elections</li>
								<li>Implemented multi-factor authentication (SMS/Email/2FA) for voter verification</li>
								<li>Developed real-time analytics dashboard showing voter participation metrics</li>
								<li>Designed responsive UI/UX for cross-device compatibility (web/mobile/tablet)</li>
								<li>Integrated with enterprise HR systems for automatic voter eligibility checks</li>
							</ul>
						</p>
					</div>

				</div>

				<div class="col-md-6">
					<div class="resume-wrap ftco-animate">
						<span class="date">2022-2026</span>
						<h2>full-Stack web developer</h2>
						<span class="position">WeatherApp</span>
						<p class="mt-4">Developed a comprehensive weather application providing hyperlocal forecasts, severe weather alerts, and climate analytics for both consumer and enterprise users.
							 The system aggregates data from multiple meteorological sources to deliver 98.5% forecast accuracy. 
							<ul>
								<li>Integrated APIs from NOAA, OpenWeatherMap, and AccuWeather.</li>
								<li>Developed proprietary algorithms for microclimate predictions.</li>
								<li>Implemented machine learning models to improve forecast accuracy.</li>
								<li>Optimized API response times under 300ms.</li>
								<li>7-day extended forecasts with precipitation probability.</li>
							</ul>
						</p>
					</div>

				</div>
			</div>

		<br>
		<br>

		<div class="row">
			<h1 class="big-4">Education</h1>
			<div class="underline"></div>
		</div>
		<br>
		
			<!-- <div class="row">
    			<div class="col-md-6">
    				<div class="resume-wrap ftco-animate">
    					<span class="date">2014-2018</span>
    					<h2>Bachelor of Engineering</h2>
    					<span class="position">Visvesvaraya Technological University</span>
    					<p class="mt-4">Grade: First class distinction.</p>
    				</div>
    			</div> -->

    			<div class="container">
					<div class="row">
					  <div class="col-md-6">
						<div class="resume-wrap ftco-animate">
						  <span class="date">2019-2021</span>
						  <h2>Higher Secondary School</h2>
						  <span class="position">S.B.N INTER COLLAGE</span>
						  <p class="mt-4">Grade: First class distinction.</p>
						</div>
					  </div>
					  <div class="col-md-6">
						<div class="resume-wrap ftco-animate">
						  <span class="date">2016-2018</span>
						  <h2>Matric class</h2>
						  <span class="position">Tilakpur High School</span>
						  <p class="mt-4">Grade: Secend class distinction.</p>
						</div>
					  </div>
					</div>
				  </div>

    		<div class="row justify-content-center mt-5">
    			<div class="col-md-6 text-center ftco-animate">
    				<p><a href="#" class="btn btn-primary py-4 px-5">Download Soon CV</a></p>
    			</div>
    		</div>
    	</div>
    </section>

   

    <section class="ftco-section" id="project-section">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-5">
          <div class="col-md-7 heading-section text-center ftco-animate">
            <h1 class="big big-2">Projects</h1>
            <h2 class="mb-4">Projects</h2>
			<p>Project Uploaded Soon</p>
            <p>Below are the sample Full-Stack web site</p>
          </div>
        </div>
        <!-- <div class="row d-flex">
          <div class="col-md-4 d-flex ftco-animate">
          	<div class="blog-entry justify-content-end">
              <a href="https://github.com/rishabhnmishra/SQL_Music_Store_Analysis/blob/main/Music_Store_Query.sql" class="block-20 zoom-effect" style="background-image: url('images/proj_1.jpg');">
              </a>
              <div class="text mt-3 float-right d-block">

                <h3 class="heading"><a href="https://github.com/rishabhnmishra/SQL_Music_Store_Analysis/blob/main/Music_Store_Query.sql">Digital Music Store Data Analysis using SQL</a></h3>
                <p>Analyzed music store data using advanced SQL queires to identify gaps and increase the business growth.</p>
              </div>
            </div>
          </div>
          <div class="col-md-4 d-flex ftco-animate">
          	<div class="blog-entry justify-content-end">
              <a href="https://github.com/rishabhnmishra/Python_Diwali_Sales_Analysis/blob/main/Diwali_Sales_Analysis.ipynb" class="block-20 zoom-effect" style="background-image: url('images/proj_2.jpg');">
              </a>
              <div class="text mt-3 float-right d-block">

                <h3 class="heading"><a href="https://github.com/rishabhnmishra/Python_Diwali_Sales_Analysis/blob/main/Diwali_Sales_Analysis.ipynb">Data Analysis using Python Project for Beginners</a></h3>
                <p>Performed exploratory data analysis on diwali sales data using Python to improve the customer experience.</p>
              </div>
            </div>
          </div>
          <div class="col-md-4 d-flex ftco-animate">
          	<div class="blog-entry">
              <a href="https://github.com/rishabhnmishra/Madhav_Store_Analysis_PowerBI/blob/main/Madhav%20Store%20dashboard.jpg" class="block-20 zoom-effect" style="background-image: url('images/proj_3.jpg');">
              </a>
              <div class="text mt-3 float-right d-block">

                <h3 class="heading"><a href="https://github.com/rishabhnmishra/Madhav_Store_Analysis_PowerBI/blob/main/Madhav%20Store%20dashboard.jpg">Power BI Sales dashboard Project for Beginners</a></h3>
                <p>Designed a power bi dashboard for Madhav Store to track and analyze the online sales data acorss India.</p>
              </div>
            </div>
          </div>
        </div>
	<br> -->
		<!-- added justify-content-center to center align the last two projects -->
		<!-- <div class="row d-flex justify-content-center">  
			<div class="col-md-4 d-flex ftco-animate">
				<div class="blog-entry justify-content-end">
				<a href="https://github.com/rishabhnmishra/sales_forecasting/tree/main" class="block-20 zoom-effect" style="background-image: url('images/proj_4.jpg');">
				</a>
				<div class="text mt-3 float-right d-block">
  
				  <h3 class="heading"><a href="https://github.com/rishabhnmishra/sales_forecasting/tree/main">Sales Forecast- Time Series Forecasting</a></h3>
				  <p>Used multiple machine learning models to forecast sales (retail store) and performed time series analysis.</p>
				</div>
			  </div>
			</div>
			<div class="col-md-4 d-flex ftco-animate">
				<div class="blog-entry justify-content-end">
				<a href="https://github.com/rishabhnmishra/customer_segmentation/blob/main/Customer_Segmentation-final.ipynb" class="block-20 zoom-effect" style="background-image: url('images/proj_5.jpg');">
				</a>
				<div class="text mt-3 float-right d-block">
  
				  <h3 class="heading"><a href="https://github.com/rishabhnmishra/customer_segmentation/blob/main/Customer_Segmentation-final.ipynb">Customer Segmentation using clustering model</a></h3>
				  <p>Developed a ML model to give various recommendations of financial products &amp; services on target customer groups.</p>
				</div>
			  </div>
			</div>
		 </div>
	  </div>
    </section> -->

	<!-- <section class="ftco-section ftco-no-pt ftco-no-pb ftco-counter img" id="section-counter">
      <div class="container">
		<div class="row d-md-flex align-items-center">
          <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
            <div class="block-18">
              <div class="text">
                <strong class="number" data-number="20">0</strong>
                <span>Achievements</span>
              </div>
            </div>
          </div>
          <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
            <div class="block-18">
              <div class="text">
                <strong class="number" data-number="30">0</strong>
                <span>Projects</span>
              </div>
            </div>
          </div>
          <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
            <div class="block-18">
              <div class="text">
                <strong class="number" data-number="1000">0</strong>
                <span>Mentored Students</span>
              </div>
            </div>
          </div>
          <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
            <div class="block-18">
              <div class="text">
                <strong class="number" data-number="500">0</strong>
                <span>Cups of coffee</span>
              </div>
            </div>
          </div>
        </div>
      </div>
	
	  <div class="ftco-section ftco-hireme img margin-top" style="background-image: url(images/bg_1.jpg)"> -->
			<!-- <div class="container"> -->
				<div class="row justify-content-center">
					<div class="col-md-7 ftco-animate text-center">
						<h2>More projects on<span> Github  </span> </h2>
						<div class="heading"> <h4> As a full-stack developer with a passion for data-driven solutions, I specialize in transforming complex business challenges into elegant technical implementations. </h4>
						<br>
						<p><a href="https://github.com/Mdsaqib7411" class="btn btn-primary py-3 px-5">GitHub</a></p>
						</div>
					</div>
				</div>
			<!-- </div> -->
		</div>
	</section>



    <section class="ftco-section contact-section ftco-no-pb" id="contact-section">
      <div class="container">
      	<div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 heading-section text-center ftco-animate">
            <h1 class="big big-2">Contact</h1>
            <h2 class="mb-4">Contact Me</h2>
            <p>Below are the details to reach out to me!</p>
          </div>
        </div>

        <div class="row d-flex contact-info mb-5">
          <div class="col-md-6 col-lg-3 d-flex ftco-animate">
          	<div class="align-self-stretch box p-4 text-center">
          		<div class="icon d-flex align-items-center justify-content-center">
          			<span class="icon-map-signs"></span>
          		</div>
          		<h3 class="mb-4">Address</h3>
	            <p>BHOPAL, India</p>
	          </div>
          </div>
          <div class="col-md-6 col-lg-3 d-flex ftco-animate">
          	<div class="align-self-stretch box p-4 text-center">
          		<div class="icon d-flex align-items-center justify-content-center">
          			<span class="icon-phone2"></span>
          		</div>
          		<h3 class="mb-4">Contact Number</h3>
	            <p><a href="tel://0101010101">+91 7295886601</a></p>
	          </div>
          </div>
          <div class="col-md-6 col-lg-3 d-flex ftco-animate">
          	<div class="align-self-stretch box p-4 text-center">
          		<div class="icon d-flex align-items-center justify-content-center">
          			<span class="icon-paper-plane"></span>
          		</div>
          		<h3 class="mb-4">Email Address</h3>
	            <p><a href="mailto:info@yoursite.com">mdsaqibhussain123@gmail.com</a></p>
	          </div>
          </div>
          <div class="col-md-6 col-lg-3 d-flex ftco-animate">
          	<div class="align-self-stretch box p-4 text-center">
          		<div class="icon d-flex align-items-center justify-content-center">
          			<span class="icon-globe"></span>
          		</div>
          		<h3 class="mb-4">Download Resume Soon</h3>
	            <p><a href="https://docs.google.com/document/d/1cC_5RTRl-giub-r4SvNwlpL5pr8XYsFy/edit?usp=drive_link&ouid=111644233603766128441&rtpof=true&sd=true">resumelink</a></p>
	          </div>
          </div>

		  <div class="container">
			<br>
			<br>
			<div class="row justify-content-center">
				<!-- <div class="col-md-7 ftco-animate text-center">
					<h2>Have a<span> Question?  </span> <a href="https://forms.gle/uLaTShUKXraAvHJ77" class="btn btn-primary py-3 px-5">Click Here</a> </h2>
				</div> -->
			</div>
				<br>
					<ul class="ftco-footer-social list-unstyled d-flex justify-content-center align-items-center mb-0">
					  <li class="ftco-animate normal-txt">Find me On  </li>
					  <li class="ftco-animate"><a href="https://www.linkedin.com/in/md-saqib-hussain-7411L7295/"><span class="icon-linkedin"></span></a></li>  
				      <li class="ftco-animate"><a href=""><span class="icon-instagram"></span></a></li>
					  <li class="ftco-animate"><a href="https://myweather8614.netlify.app"><span class="icon-OpenWeather"></span></a></li>
					  <li class="ftco-animate"><a href="https://www.https://github.com/Mdsaqib7411/"><span class="icon-github"></span></a></li>
					</ul>
				<br>
		   </div>
   </div>
 </section>

<!-- ✅ Include SweetAlert2 -->
<footer class="ftco-footer ftco-section">
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center">

        <div class="comments-section">
          <h3>Comments</h3>
          <div class="comment-form">
            <input type="email" id="user-email" class="form-control" placeholder="Enter your Gmail..." required>
            <textarea id="comment-text" class="form-control mt-2" placeholder="Add a comment..." required></textarea>
            <button id="submit-comment" class="btn btn-primary mt-2">Post Comment</button>

            <div class="like-section mt-3">
              <button id="like-button" class="btn btn-outline-danger">
                <i class="icon-heart"></i> <span id="like-count">0</span> Likes
              </button>
            </div>
          </div>

          <div class="comments-list mt-4" id="comments-container">
            <!-- Comments will be loaded here -->
          </div>
        </div>

        <p class="mt-5">
          Copyright &copy;<script>document.write(new Date().getFullYear());</script>
          All rights reserved | This template is made with
          <i class="icon-heart color-danger" aria-hidden="true"></i> by
          <a href="https://colorlib.com" target="_blank">Colorlib</a>
        </p>
      </div>
    </div>
  </div>
</footer>

<!-- ✅ SweetAlert2 for popups -->
<!-- <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> -->

<script>
document.addEventListener('DOMContentLoaded', () => {
  const likeButton = document.getElementById('like-button');
  const commentButton = document.getElementById('submit-comment');

  loadComments();
  loadLikeStatus();

  // 👍 Like button
  likeButton.addEventListener('click', () => {
    fetch('like_post.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    })
    .then(parseJSON)
    .then(data => {
      if (data.action === 'liked') {
        likeButton.classList.add('liked');
        updateLikeCount(1);
        showSuccess("You liked this post ❤️");
      } else if (data.action === 'unliked') {
        likeButton.classList.remove('liked');
        updateLikeCount(-1);
        showSuccess("Like removed 💔");
      } else {
        showError("Unexpected like action.");
      }
    })
    .catch(handleError);
  });

  // 📝 Post comment
  commentButton.addEventListener('click', () => {
    const email = document.getElementById('user-email').value.trim();
    const comment = document.getElementById('comment-text').value.trim();
    const gmailPattern = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;

    if (!gmailPattern.test(email)) {
      return showError('Please enter a valid Gmail address.');
    }

    if (comment.length < 3) {
      return showError('Comment must be at least 3 characters.');
    }

    fetch('post_comment.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, comment })
    })
    .then(parseJSON)
    .then(data => {
      if (data.success) {
        document.getElementById('comment-text').value = '';
        loadComments();
        showSuccess("Comment successfully sent ✅");
      } else {
        showError(data.message || "Failed to post comment.");
      }
    })
    .catch(handleError);
  });

  // 📥 Load comments
  function loadComments() {
    fetch('get_comments.php')
      .then(parseJSON)
      .then(comments => {
        const container = document.getElementById('comments-container');
        container.innerHTML = comments.map(comment => `
          <div class="comment-item mb-3 p-3 border rounded">
            <strong>${escapeHtml(comment.email)}</strong>
            <div class="comment-text">${escapeHtml(comment.comment)}</div>
            <div class="comment-time small text-muted">${new Date(comment.created_at).toLocaleString()}</div>
          </div>
        `).join('');
      })
      .catch(handleError);
  }

  // ❤️ Load likes
  function loadLikeStatus() {
    fetch('get_likes.php')
      .then(parseJSON)
      .then(data => {
        document.getElementById('like-count').textContent = data.totalLikes;
        if (data.hasLiked) {
          likeButton.classList.add('liked');
        }
      })
      .catch(handleError);
  }

  // 🔢 Count updater
  function updateLikeCount(change) {
    const count = document.getElementById('like-count');
    const newVal = Math.max(0, parseInt(count.textContent || '0') + change);
    count.textContent = newVal;
  }

  // 🧠 JSON safety
  function parseJSON(response) {
    return response.text().then(text => {
      try {
        return JSON.parse(text);
      } catch (e) {
        console.error("Invalid JSON:", text);
        throw new Error("Server returned invalid JSON.");
      }
    });
  }

  // 🛡️ Escape HTML
  function escapeHtml(text) {
    return text.replace(/&/g, "&amp;")
               .replace(/</g, "&lt;")
               .replace(/>/g, "&gt;")
               .replace(/"/g, "&quot;")
               .replace(/'/g, "&#039;");
  }

  // ✅ Alert: Success
  function showSuccess(message) {
    Swal.fire({
      title: 'Success!',
      text: message,
      icon: 'success',
      timer: 1300,
      showConfirmButton: false
    });
  }

  // ❌ Alert: Error
  function showError(message) {
    Swal.fire({
      title: 'Error',
      text: message,
      icon: 'error',
      timer: 2000,
      showConfirmButton: true
    });
  }

  // ⚠️ Log error
  function handleError(error) {
    console.error("Error:", error.message || error);
    showError(error.message || "Something went wrong.");
  }
  if (data.success) {
  document.getElementById('comment-text').value = '';
  document.getElementById('user-email').value = ''; // clear email
  loadComments();
  showSuccess("Comment successfully sent ✅");
}


});
</script>



  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="comment_handler.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>