<?php
header('Content-Type: application/json'); // Set JSON header first

include 'config.php';
session_start();

$user_ip = $_SERVER['REMOTE_ADDR'];

// Check if the user has already liked
$check = $conn->prepare("SELECT * FROM likes WHERE ip = ?");
$check->bind_param("s", $user_ip);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    // Unlike: Remove like
    $delete = $conn->prepare("DELETE FROM likes WHERE ip = ?");
    $delete->bind_param("s", $user_ip);
    $delete->execute();
    echo json_encode(['action' => 'unliked']);
} else {
    // Like: Insert new like
    $insert = $conn->prepare("INSERT INTO likes (ip) VALUES (?)");
    $insert->bind_param("s", $user_ip);
    $insert->execute();
    echo json_encode(['action' => 'liked']);
}
?>
