<?php
header('Content-Type: application/json');
include 'config.php';

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Only POST requests are allowed');
    }

    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($data['email'], $data['comment'])) {
        throw new Exception('Email and comment are required');
    }

    $email = filter_var($data['email'], FILTER_SANITIZE_EMAIL);
    $comment = trim($data['comment']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strpos($email, '@gmail.com') === false) {
        throw new Exception('Only valid Gmail addresses are allowed');
    }

    if (strlen($comment) < 3 || strlen($comment) > 500) {
        throw new Exception('Comment must be between 3 and 500 characters');
    }

    $stmt = $conn->prepare("INSERT INTO comments (email, comment) VALUES (?, ?)");
    $stmt->bind_param("ss", $email, $comment);

    if ($stmt->execute()) {
        $response = ['success' => true, 'message' => 'Comment successfully posted'];
    } else {
        throw new Exception('Database insert failed: ' . $stmt->error);
    }

    $stmt->close();
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    http_response_code(400);
} finally {
    $conn->close();
    echo json_encode($response);
}
?>
